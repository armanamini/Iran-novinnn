import React from "react";

const Loader = () => {
  return (
<div class="loadingio-spinner-spin-y6ggja1qfm"><div class="ldio-6z1brikolqi">
<div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div><div><div></div></div>
</div></div>
  );
};

export default Loader;
