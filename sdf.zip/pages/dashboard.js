import React from 'react'

const dashboard = () => {
  return (
    <div className='text-black font-[70px] text-center py-10 '> با موفقیت وارد شدید</div>
  )
}

export default dashboard